#include <iostream>
using namespace std;

// Declare the function prototype
int lut_square(int x);

int main() {
    for (int i = 0; i < 8; i++) {
        int result = lut_square(i);
        cout << "lut_square(" << i << ") = " << result << endl;
    }
    return 0;
}

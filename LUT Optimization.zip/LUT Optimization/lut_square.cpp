#include <ap_int.h>

// Top function for HLS
int lut_square(int x) {
    const int LUT[8] = {0, 1, 4, 9, 16, 25, 36, 49};
    return LUT[x];
}
